enum SenderType {
    DOCTOR = 'DOCTOR',
    PATIENT = 'PATIENT'
}