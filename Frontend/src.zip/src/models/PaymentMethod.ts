enum PaymentMethod {
    PAYPAL = 'PAYPAL',
    BANK_TRANSFER = 'BANK_TRANSFER',
    CASH = 'CASH',
}