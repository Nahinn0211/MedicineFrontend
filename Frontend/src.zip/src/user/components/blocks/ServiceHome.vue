<template>
    <section class="section service gray-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7 text-center">
                    <div class="section-title">
                        <h2>Dịch vụ chăm sóc bệnh nhân đạt giải thưởng</h2>
                        <div class="divider mx-auto my-4"></div>
                        <p>Hãy cùng tìm hiểu thêm về các dịch vụ y tế chất lượng cao, giúp bạn an tâm hơn trong việc chăm sóc sức khỏe.</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="service-item mb-4">
                        <div class="icon d-flex align-items-center">
                            <i class="icofont-laboratory text-lg"></i>
                            <h4 class="mt-3 mb-3">Dịch vụ xét nghiệm</h4>
                        </div>

                        <div class="content">
                            <p class="mb-4">Cung cấp dịch vụ xét nghiệm nhanh chóng và chính xác.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="service-item mb-4">
                        <div class="icon d-flex align-items-center">
                            <i class="icofont-heart-beat-alt text-lg"></i>
                            <h4 class="mt-3 mb-3">Bệnh tim mạch</h4>
                        </div>
                        <div class="content">
                            <p class="mb-4">Chăm sóc và điều trị các bệnh liên quan đến tim mạch.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="service-item mb-4">
                        <div class="icon d-flex align-items-center">
                            <i class="icofont-tooth text-lg"></i>
                            <h4 class="mt-3 mb-3">Chăm sóc răng miệng</h4>
                        </div>
                        <div class="content">
                            <p class="mb-4">Dịch vụ nha khoa chuyên nghiệp cho mọi lứa tuổi.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="service-item mb-4">
                        <div class="icon d-flex align-items-center">
                            <i class="icofont-crutch text-lg"></i>
                            <h4 class="mt-3 mb-3">Phẫu thuật thẩm mỹ</h4>
                        </div>

                        <div class="content">
                            <p class="mb-4">Dịch vụ phẫu thuật thẩm mỹ an toàn và hiện đại.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="service-item mb-4">
                        <div class="icon d-flex align-items-center">
                            <i class="icofont-brain-alt text-lg"></i>
                            <h4 class="mt-3 mb-3">Phẫu thuật thần kinh</h4>
                        </div>
                        <div class="content">
                            <p class="mb-4">Chẩn đoán và điều trị các bệnh lý thần kinh.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="service-item mb-4">
                        <div class="icon d-flex align-items-center">
                            <i class="icofont-dna-alt-1 text-lg"></i>
                            <h4 class="mt-3 mb-3">Sản phụ khoa</h4>
                        </div>
                        <div class="content">
                            <p class="mb-4">Dịch vụ chăm sóc sức khỏe sinh sản và thai sản.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>


<script setup>
// Component logic if needed
</script>

<style scoped>
/* Styles specific to this component */
</style>