<template>
    <section class="features">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="feature-block d-lg-flex">
                        <div class="feature-item mb-5 mb-lg-0">
                            <div class="feature-icon mb-4">
                                <i class="icofont-surgeon-alt"></i>
                            </div>
                            <span>Dịch Vụ 24 Giờ</span>
                            <h4 class="mb-3">Đặt Lịch Hẹn Trực Tuyến</h4>
                            <p class="mb-4">Hỗ trợ khẩn cấp mọi lúc. Chúng tôi đã áp dụng nguyên tắc y học gia đình.</p>
                            <a href="" class="btn btn-main btn-round-full">Đặt Lịch Hẹn</a>
                        </div>

                        <div class="feature-item mb-5 mb-lg-0">
                            <div class="feature-icon mb-4">
                                <i class="icofont-ui-clock"></i>
                            </div>
                            <span>Lịch Làm Việc</span>
                            <h4 class="mb-3">Giờ Làm Việc</h4>
                            <ul class="w-hours list-unstyled">
                                <li class="d-flex justify-content-between">Chủ Nhật - Thứ Tư: <span>8:00 - 17:00</span></li>
                                <li class="d-flex justify-content-between">Thứ Năm - Thứ Sáu: <span>9:00 - 17:00</span></li>
                                <li class="d-flex justify-content-between">Thứ Bảy - Chủ Nhật: <span>10:00 - 17:00</span></li>
                            </ul>
                        </div>

                        <div class="feature-item mb-5 mb-lg-0">
                            <div class="feature-icon mb-4">
                                <i class="icofont-support"></i>
                            </div>
                            <span>Trường Hợp Khẩn Cấp</span>
                            <h4 class="mb-3">1-800-700-6200</h4>
                            <p>Hỗ trợ khẩn cấp mọi lúc. Chúng tôi đã áp dụng nguyên tắc y học gia đình. Kết nối ngay với chúng tôi khi cần thiết.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script setup>
// Logic của component (nếu cần)
</script>

<style scoped>
/* CSS dành riêng cho component này */
</style>
