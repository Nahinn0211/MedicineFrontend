<template>
    <div id="user-app">
        <router-view />
    </div>
</template>

<script>
export default {
  name: 'UserApp'
};
</script>

<script setup>
</script>

<style scoped></style>