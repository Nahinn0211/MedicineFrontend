<template>
    <main>
        <Header />
        <TeleMedicine />
        <Footer />
    </main>
</template>

<script setup>
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
import TeleMedicine from '@user/components/blocks/TeleMedicine.vue';
</script>