<template>
    <main>
        <Header />
        <Cart />
        <Footer />
    </main>
</template>

<script setup>
import Cart from '@/user/components/blocks/Cart.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>