<template>
    <main>
        <Header />
        <ListOrder />
        <Footer />
    </main>
</template>

<script setup>
import ListOrder from '@/user/components/blocks/ListOrder.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>