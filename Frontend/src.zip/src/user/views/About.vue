<template>
    <main>
        <Header />
        <AboutPage />
        <Footer />
    </main>
</template>

<script setup>
import AboutPage from '@/user/components/blocks/AboutPage.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>