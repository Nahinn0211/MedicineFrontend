<template>
    <main>
        <Header />
        <ForgotPassword />
        <Footer />
    </main>
</template>

<script setup>
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
import ForgotPassword from '@user/components/blocks/ForgotPassword.vue';
</script>