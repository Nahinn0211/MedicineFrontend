<template>
    <main>
        <Header />
        <Shop />
        <Footer />
    </main>
</template>

<script setup>
import Shop from '@/user/components/blocks/Shop.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>