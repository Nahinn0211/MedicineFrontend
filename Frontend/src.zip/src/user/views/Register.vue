<template>
    <main>
        <Header />
        <Register />
        <Footer />
    </main>
</template>

<script setup>
import Register from '@/user/components/blocks/Register.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>