<template>
    <main>
        <Header />
        <Contact />
        <Footer />
    </main>
</template>

<script setup>
import Contact from '@/user/components/blocks/Contact.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>