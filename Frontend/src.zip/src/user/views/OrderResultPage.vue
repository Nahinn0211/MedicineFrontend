<template>
    <main>
        <Header />
        <ResultOrder />
        <Footer />
    </main>
</template>

<script setup>
import ResultOrder from '@/user/components/blocks/ResultOrder.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>