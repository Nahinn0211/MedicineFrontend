<template>
    <main>
        <Header />
        <Medicine />
        <Footer />
    </main>
</template>

<script setup>
import Medicine from '@/user/components/blocks/Medicine.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>