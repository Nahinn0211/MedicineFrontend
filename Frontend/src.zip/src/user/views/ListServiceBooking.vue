<template>
    <main>
        <Header />
        <ListServiceBooking />
        <Footer />
    </main>
</template>

<script setup>
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
import ListServiceBooking from '@user/components/blocks/ListServiceBooking.vue';
</script>