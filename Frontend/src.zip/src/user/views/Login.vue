<template>
    <main>
        <Header />
        <Login />
        <Footer />
    </main>
</template>

<script setup>
import Login from '@/user/components/blocks/Login.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>