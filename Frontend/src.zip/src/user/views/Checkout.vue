<template>
    <main>
        <Header />
        <CheckOut />
        <Footer />
    </main>
</template>

<script setup>
import CheckOut from '@/user/components/blocks/CheckOut.vue';
import Header from '../views/layout/Header.vue';
import Footer from '../views/layout/Footer.vue';
</script>