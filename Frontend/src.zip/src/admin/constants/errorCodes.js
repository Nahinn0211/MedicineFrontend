export const errorCodes = {
  notFound: 404,
  accessTokenExpired: 403
}