const apiEndPoint = {
     
};

export default apiEndPoint;
