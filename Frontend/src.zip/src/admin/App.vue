<template>
    <div id="admin-app">
        <router-view />
    </div>
</template>

<script>
export default {
  name: 'AdminApp'
};
</script>